function add (left, right) {
    return left + right;
}

module.exports = add;